module.exports = {
    mongodb: {
        URI: 'mongodb://a19angavimar:Grup5@labs.inspedralbes.cat:7010/?authMechanism=DEFAULT&authSource=DAMA_Grup5&tls=false'
    }
}