<template>
						<div class="team">
							<h1 class="subheading grey--text">Team</h1>
						<v-container class="my-5">
					<v-layout row wrap>
						<v-flex xs12 sm6 md4 lg3 v-for="person in team" :key="person.name">
							<v-card flat class="text-xs-center ma-3">hello
							<v-responsive class="pt-4">
								imagen aka
							</v-responsive>
							<v-card-text>
								<div class="subheading">{{person.name}}</div>
								<div class="grey--text">{{person.role}}</div>
							</v-card-text>
							</v-card>
                            </v-flex>
					    </v-layout>
					</v-container>
						</div>
					</template>
					<script>
						export default{
							data(){
								return{
									team:[
							{	name:'Knight', role:'Web developer'		},
							{	name:'Ryuk', role:'Web developer'		},
							{	name:'Sasuke', role:'Web developer'		},
							{	name:'Sokulol', role:'Web developer'	}
									]
								}
							}
						}


					</script>